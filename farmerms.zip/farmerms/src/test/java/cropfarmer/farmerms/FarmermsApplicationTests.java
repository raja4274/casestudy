package cropfarmer.farmerms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FarmermsApplicationTests {

	@Test
	void contextLoads() {
	}

}
