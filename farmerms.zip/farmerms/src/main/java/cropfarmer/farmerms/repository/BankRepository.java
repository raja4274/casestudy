package cropfarmer.farmerms.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;

import cropfarmer.farmerms.model.BankDetails;

public interface BankRepository extends MongoRepository<BankDetails,Integer> {

	List<BankDetails> findByFarmerId(int farmerId);

}
