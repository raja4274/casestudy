package cropfarmer.farmerms.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import cropfarmer.farmerms.model.FarmerProfile;

public interface FarmerRepository extends MongoRepository<FarmerProfile,Integer>{

	FarmerProfile findByUsername(String username);

}
