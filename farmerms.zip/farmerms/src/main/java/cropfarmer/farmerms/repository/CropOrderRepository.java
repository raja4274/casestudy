package cropfarmer.farmerms.repository;

import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;

import cropfarmer.farmerms.model.CropOrders;




public interface CropOrderRepository extends MongoRepository<CropOrders,Integer>{

	Optional<CropOrders> findByDealerId(String dealerId);

}
