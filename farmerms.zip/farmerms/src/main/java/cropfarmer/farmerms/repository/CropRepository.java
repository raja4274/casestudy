package cropfarmer.farmerms.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;

import cropfarmer.farmerms.model.CropDetails;

public interface CropRepository extends MongoRepository<CropDetails,Integer>{

	List<CropDetails> findByFarmerId(int farmerId);



}
