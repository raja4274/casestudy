package cropfarmer.farmerms.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import cropfarmer.farmerms.model.BankDetails;
import cropfarmer.farmerms.repository.BankRepository;

@RestController
public class BankController {

	@Autowired
	private BankRepository bank;
	
	//adding farmer bank details
	@PostMapping("/addBankDetails")
	public int saveBankDet(@RequestBody BankDetails bankDetails ) {
	bank.save(bankDetails);
	return bankDetails.getId();
	}
	
	//getting farmer bank details by using id
	@GetMapping("/findABank/{id}")
	public Optional<BankDetails> getBankDet(@PathVariable int id)
	{
        return bank.findById(id);
	}
	@GetMapping("/findABank/{farmerId}")
	public List<BankDetails> getBankDetailsByFarmerId(@PathVariable int farmerId)
	{
        return bank.findByFarmerId(farmerId);
	}
	
	//updating bank details with reference of id
	@PutMapping("/updateBankDetails")
	public void updateBank(@RequestBody BankDetails bankdetails) {
	bank.save(bankdetails);
	}
	
	//deleting bank details using id
	@DeleteMapping("/deleteBankDetails/{id}")
	public String deleteBankDet(@PathVariable int id) {
		bank.deleteById(id);
		return "Crop details deleted with id: " +id;
	}
	
	//getting all farmers bank details
	@GetMapping("/findAllBankDetails")
	public List<BankDetails> getBankDet()
	{
		return bank.findAll();
	}
}
