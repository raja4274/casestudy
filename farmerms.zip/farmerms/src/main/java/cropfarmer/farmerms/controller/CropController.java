package cropfarmer.farmerms.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import cropfarmer.farmerms.model.CropDetails;
import cropfarmer.farmerms.repository.CropRepository;

@RestController
public class CropController {

	@Autowired
	private CropRepository repo;
	
	
	
	//adding crop details by giving id
	@PostMapping("/addCrop")
	public int saveCrop(@RequestBody CropDetails details ) {
	repo.save(details);
	return details.getId();
	}
	
	//getting single crop details by using id
	@GetMapping("/findSingleCrop/{cropId}")
	public Optional<CropDetails> getCrop(@PathVariable int id)
	{
        return repo.findById(id);
	}
	
	@GetMapping("/findSingleFarmerCrops/{id}")
	public List<CropDetails> getCropByFarmerId(@PathVariable int farmerId)
	{
		
        return repo.findByFarmerId(farmerId);
        
	}
	
	//updated after sold
	@PutMapping("/updateCrops")
	public String updateQuantity(@RequestBody CropDetails quantity) {
		repo.save(quantity);
		return "updated";
	}
	
	//deleting crop details by using id
	@DeleteMapping("/deleteCrop/{id}")
	public String deleteCrop(@PathVariable int id) {
		repo.deleteById(id);
		return "Crop details deleted with id: " +id;
	}
	
	//getting all crop details which are added
	@GetMapping("/findAllCrops")
	public List<CropDetails> getCrops()
	{
		return repo.findAll();
	}
	
}
