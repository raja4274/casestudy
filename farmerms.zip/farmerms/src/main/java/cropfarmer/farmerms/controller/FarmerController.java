package cropfarmer.farmerms.controller;

import java.util.List;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import cropfarmer.farmerms.model.FarmerProfile;
import cropfarmer.farmerms.repository.FarmerRepository;

@RestController
public class FarmerController {

	@Autowired
	private FarmerRepository repository;
	
	//adding farmer details using post mapping and giving id
	@PostMapping("/addFarmer")
	public int saveFarmer(@RequestBody FarmerProfile profile ) {
	repository.save(profile);
	return profile.getId();
	}
	
	//getting single farmer details using id
	@GetMapping("/findSingleFarmer/{id}")
	public Optional<FarmerProfile> getFarmer(@PathVariable int id)
	{
        return repository.findById(id);
	}
	
	//deleting farmer details using id
	@DeleteMapping("/deleteFarmerDetails/{id}")
	public String deleteFarmer(@PathVariable int id) {
		repository.deleteById(id);
		return "Farmer details deleted with id: " +id;
	}
	
	//getting all farmers details
	@GetMapping("/findAllFarmers")
	public List<FarmerProfile> getFarmers()
	{
		return repository.findAll();
	}
	
	
}
