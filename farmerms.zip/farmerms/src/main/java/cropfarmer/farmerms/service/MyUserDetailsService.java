package cropfarmer.farmerms.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import cropfarmer.farmerms.repository.FarmerRepository;

@Service
public class MyUserDetailsService implements UserDetailsService{
	
	@Autowired
	FarmerRepository repository;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		cropfarmer.farmerms.model.FarmerProfile user= repository.findByUsername(username);
		System.out.println(user);
	return new User(user.getUsername(), user.getPassword(), new ArrayList<>());
	}


}
