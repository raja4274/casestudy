package cropfarmer.farmerms.model;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="cropOrders")
public class CropOrders {

	private int id;
	private String dealerId;
	private String crop1;
	private String farmerId;
	private int quantity1;
	
	
	
	public CropOrders(int id, String dealerId, String crop1, String farmerId, int quantity1) {
		super();
		this.id = id;
		this.dealerId = dealerId;
		this.crop1 = crop1;
		this.farmerId = farmerId;
		this.quantity1 = quantity1;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDealerId() {
		return dealerId;
	}
	public void setDealerId(String dealerId) {
		this.dealerId = dealerId;
	}
	public String getCrop1() {
		return crop1;
	}
	public void setCrop1(String crop1) {
		this.crop1 = crop1;
	}
	public String getFarmerId() {
		return farmerId;
	}
	public void setFarmerId(String farmerId) {
		this.farmerId = farmerId;
	}
	public int getQuantity1() {
		return quantity1;
	}
	public void setQuantity1(int quantity1) {
		this.quantity1 = quantity1;
	}
	
	
	
}
