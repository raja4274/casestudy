package cropfarmer.farmerms.model;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="bankDetailsFarmer")
public class BankDetails {

	//bank details taking
	private int id;
	private int farmerId;
	private String accountNumber;
	private String ifscCode;
	private String accountHolderName;
	
	
	public BankDetails(int id,int farmerId,String accountNumber, String ifscCode, String accountHolderName) {
		super();
		this.id=id;
		this.farmerId=farmerId;
		this.accountNumber = accountNumber;
		this.ifscCode = ifscCode;
		this.accountHolderName = accountHolderName;
	}


	public int getId() {
		return id;
	}



	public void setId(int id) {
		this.id = id;
	}



	public int getFarmerId() {
		return farmerId;
	}


	public void setFarmerId(int farmerId) {
		this.farmerId = farmerId;
	}


	public String getAccountNumber() {
		return accountNumber;
	}


	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}


	public String getIfscCode() {
		return ifscCode;
	}


	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}


	public String getAccountHolderName() {
		return accountHolderName;
	}


	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}
	
	
}
