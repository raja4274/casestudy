package cropdealer.dealerms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DealermsApplicationTests {

	@Test
	void contextLoads() {
	}

}
