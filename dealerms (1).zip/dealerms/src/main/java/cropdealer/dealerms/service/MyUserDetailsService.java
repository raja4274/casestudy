package cropdealer.dealerms.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import cropdealer.dealerms.model.DealerProfile;
import cropdealer.dealerms.repository.DealerRepository;

@Service
public class MyUserDetailsService implements UserDetailsService{
	
	@Autowired
	DealerRepository repository;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		cropdealer.dealerms.model.DealerProfile user= repository.findByUsername(username);
		System.out.println(user);
	return new User(user.getUsername(), user.getPassword(), new ArrayList<>());
	}

}
