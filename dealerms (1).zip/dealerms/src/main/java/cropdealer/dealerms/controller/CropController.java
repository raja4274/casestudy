package cropdealer.dealerms.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import cropdealer.dealerms.model.CropDetails;



@RestController
public class CropController {

	@Autowired
	private RestTemplate restTemplate;
	

	
	//getting all crop details which are added
	
	@GetMapping("/findAllCrops")
    public CropDetails[] getAddOn(){
        ResponseEntity<CropDetails[]> response = restTemplate.getForEntity("http://localhost:8081/findAllCrops", CropDetails[].class);
        CropDetails[] crops = response.getBody();
        return crops.clone();
    }
	
}
