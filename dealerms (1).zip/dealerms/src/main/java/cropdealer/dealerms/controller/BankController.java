package cropdealer.dealerms.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cropdealer.dealerms.model.BankDetails;
import cropdealer.dealerms.repository.BankRepository;

@RestController
@RequestMapping("/dealer")
public class BankController {

	@Autowired
	private BankRepository bank;
	
	//adding farmer bank details
	@PostMapping("/addBankDetails")
	public int saveBankDet(@RequestBody BankDetails bankDetails ) {
	bank.save(bankDetails);
	return bankDetails.getId();
	}
	
	//getting farmer bank details by using id
	@GetMapping("/findABankDetails/{id}")
	public Optional<BankDetails> getBankDet(@PathVariable int id)
	{
        return bank.findById(id);
	}
	
	//updating bank details with reference of id
	@PutMapping("/updateBankDetails")
	public void updateBank(@RequestBody BankDetails bankdetails) {
	bank.save(bankdetails);
	}
	@GetMapping("/findABankDetails/{dealerId}")
	public List<BankDetails> getBankDetailsByDealerId(@PathVariable int dealerId)
	{
		return bank.findByDealerId(dealerId);
	}
	
	//deleting bank details using id
	@DeleteMapping("/deleteBankDetails/{id}")
	public String deleteBankDet(@PathVariable int id) {
		bank.deleteById(id);
		return "Crop details deleted with id: " +id;
	}
	
	//getting all farmers bank details
	@GetMapping("/findAllBankdetails")
	public List<BankDetails> getBankDet()
	{
		return bank.findAll();
	}
}
