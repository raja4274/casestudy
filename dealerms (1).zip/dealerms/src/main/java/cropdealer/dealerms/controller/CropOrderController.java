package cropdealer.dealerms.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import cropdealer.dealerms.model.CropOrders;
import cropdealer.dealerms.repository.CropOrderRepository;


@RestController
public class CropOrderController {
	
	@Autowired
	CropOrderRepository cropOrderRepository;

	@PostMapping("/addOrder")
	public int addDealer(@RequestBody CropOrders profile ) {
	cropOrderRepository.save(profile);
	return profile.getId();
	}
	
	//getting single order details using id
	@GetMapping("/findSingleOrder/{id}")
	public Optional<CropOrders> getFarmer(@PathVariable int id)
	{
        return cropOrderRepository.findById(id);
	}
	@GetMapping("/findSingleDealerOrders/{dealerId}")
	public Optional<CropOrders> getCropByFarmerId(@PathVariable String dealerId)
	{
        return cropOrderRepository.findByDealerId(dealerId);
	}
	
	//getting all order details
	@GetMapping("/findAllOrders")
	public List<CropOrders> getFarmers()
	{
		return cropOrderRepository.findAll();
	}
}
