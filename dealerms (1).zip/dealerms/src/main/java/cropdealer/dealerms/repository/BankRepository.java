package cropdealer.dealerms.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import cropdealer.dealerms.model.BankDetails;



public interface BankRepository extends MongoRepository<BankDetails,Integer> {

	List<BankDetails> findByDealerId(int dealerId);

}
