package cropdealer.dealerms.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import cropdealer.dealerms.model.DealerProfile;

public interface DealerRepository extends MongoRepository<DealerProfile,Integer> {

	DealerProfile findByUsername(String username);


}
