package cropdealer.dealerms.repository;

import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;

import cropdealer.dealerms.model.CropDetails;



public interface CropRepository extends MongoRepository<CropDetails,Integer>{

	Optional<CropDetails> findByFarmerId(String farmerId);

}
