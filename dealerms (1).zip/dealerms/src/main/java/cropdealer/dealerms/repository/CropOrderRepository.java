package cropdealer.dealerms.repository;

import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;

import cropdealer.dealerms.model.CropOrders;


public interface CropOrderRepository extends MongoRepository<CropOrders,Integer>{

	Optional<CropOrders> findByDealerId(String dealerId);


}
