package cropdealer.dealerms.practice;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import cropdealer.dealerms.model.CropOrders;
import cropdealer.dealerms.repository.CropOrderRepository;


public class practice {

	@Autowired
	CropOrderRepository cropOrderRepository;}
	
//@GetMapping("/findSingleOrder/{id}")
//	public void getFarmer(@PathVariable int id)
//	{
//        int quantity=cropOrderRepository.getQuantity(id);
//    
//        System.out.println(quantity);
//	} 
//}








/*import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import cropdealer.dealerms.model.CropDetails;
import cropdealer.dealerms.model.CropOrders;








CropOrder cropOrder=new CropOrder();
CropDetails cropDetails = new CropDetails();
cropOrderRepository.findByCropOrderId(id//crop order id);
int cropId=cropOrder.id;
repo.findByCropId(cropId);
int orderedQuantity=cropOrder.quantity1;//comes from cropOrders collection
int originalQuantity=cropDetails.quantity;//comes from cropdetails collection
public String method(){

	originalQuantity=originalQuantity - orderedQuantity;
	cropDetails.quantity=originalQuantity
		}
			
}*/