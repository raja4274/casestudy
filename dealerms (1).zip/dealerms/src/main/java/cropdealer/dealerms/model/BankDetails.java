package cropdealer.dealerms.model;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="bankDetailsDealer")
public class BankDetails {

	private int id;
	private int dealerId;
	private String accountNumber;
	private String ifscCode;
	private String accountHolderName;
	
	
	public BankDetails(int id,int dealerId,String accountNumber, String ifscCode, String accountHolderName) {
		super();
		this.id=id;
		this.dealerId=dealerId;
		this.accountNumber = accountNumber;
		this.ifscCode = ifscCode;
		this.accountHolderName = accountHolderName;
	}

	

	public int getId() {
		return id;
	}



	public void setId(int id) {
		this.id = id;
	}



	public int getDealerId() {
		return dealerId;
	}



	public void setDealerId(int dealerId) {
		this.dealerId = dealerId;
	}



	public String getAccountNumber() {
		return accountNumber;
	}


	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}


	public String getIfscCode() {
		return ifscCode;
	}


	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}


	public String getAccountHolderName() {
		return accountHolderName;
	}


	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}
	
	
}
