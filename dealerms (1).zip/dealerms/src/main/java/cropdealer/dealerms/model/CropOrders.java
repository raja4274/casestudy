package cropdealer.dealerms.model;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="cropOrders")
public class CropOrders {

	private int id;
	private String dealerId;
	private int cropId1;
	private int quantity1;
	
	
	
	public CropOrders(int id, String dealerId, int cropId1, int quantity1) {
		super();
		this.id = id;
		this.dealerId = dealerId;
		this.cropId1 = cropId1;
		this.quantity1 = quantity1;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDealerId() {
		return dealerId;
	}
	public void setDealerId(String dealerId) {
		this.dealerId = dealerId;
	}
	
	public int getCropId1() {
		return cropId1;
	}
	public void setCropId1(int cropId1) {
		this.cropId1 = cropId1;
	}
	public int getQuantity1() {
		return quantity1;
	}
	public void setQuantity1(int quantity1) {
		this.quantity1 = quantity1;
	}
	
	
	
}
