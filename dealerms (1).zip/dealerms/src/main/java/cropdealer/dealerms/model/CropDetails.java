package cropdealer.dealerms.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document(collection="cropDetails1")
public class CropDetails {

	//taking crop details
	@Id
	private int id;
	private int farmerId;
	private String crop;
	private int quantity;
	private int price;
	private String status;
	public CropDetails(int id, int farmerId, String crop, int quantity, int price, String status) {
		super();
		this.id = id;
		this.farmerId = farmerId;
		this.crop = crop;
		this.quantity = quantity;
		this.price = price;
		this.status = status;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getFarmerId() {
		return farmerId;
	}
	public void setFarmerId(int farmerId) {
		this.farmerId = farmerId;
	}
	public String getCrop() {
		return crop;
	}
	public void setCrop(String crop) {
		this.crop = crop;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public CropDetails() {
		super();
	}
	
	
}
